﻿
namespace AyukarmaFinal
{
    partial class BuyHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuyHomePage));
            this.gunaElipsePanel1 = new Guna.UI.WinForms.GunaElipsePanel();
            this.gunaElipsePanel2 = new Guna.UI.WinForms.GunaElipsePanel();
            this.gunaButton15 = new Guna.UI.WinForms.GunaButton();
            this.gunaCirclePictureBox3 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gunaCirclePictureBox2 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaButton8 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton7 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton6 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton5 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton4 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton3 = new Guna.UI.WinForms.GunaButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gunaButton9 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton10 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton11 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton12 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton13 = new Guna.UI.WinForms.GunaButton();
            this.gunaButton14 = new Guna.UI.WinForms.GunaButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.gunaCirclePictureBox4 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gunaElipsePanel1.SuspendLayout();
            this.gunaElipsePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaElipsePanel1
            // 
            this.gunaElipsePanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaElipsePanel1.BaseColor = System.Drawing.Color.Teal;
            this.gunaElipsePanel1.Controls.Add(this.gunaElipsePanel2);
            this.gunaElipsePanel1.Location = new System.Drawing.Point(594, 27);
            this.gunaElipsePanel1.Name = "gunaElipsePanel1";
            this.gunaElipsePanel1.Size = new System.Drawing.Size(553, 555);
            this.gunaElipsePanel1.TabIndex = 17;
            // 
            // gunaElipsePanel2
            // 
            this.gunaElipsePanel2.BackColor = System.Drawing.Color.Transparent;
            this.gunaElipsePanel2.BaseColor = System.Drawing.Color.White;
            this.gunaElipsePanel2.Controls.Add(this.gunaButton15);
            this.gunaElipsePanel2.Controls.Add(this.gunaCirclePictureBox3);
            this.gunaElipsePanel2.Controls.Add(this.label7);
            this.gunaElipsePanel2.Controls.Add(this.label5);
            this.gunaElipsePanel2.Location = new System.Drawing.Point(3, 3);
            this.gunaElipsePanel2.Name = "gunaElipsePanel2";
            this.gunaElipsePanel2.Size = new System.Drawing.Size(547, 549);
            this.gunaElipsePanel2.TabIndex = 0;
            // 
            // gunaButton15
            // 
            this.gunaButton15.AnimationHoverSpeed = 0.07F;
            this.gunaButton15.AnimationSpeed = 0.03F;
            this.gunaButton15.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton15.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton15.BorderColor = System.Drawing.Color.Black;
            this.gunaButton15.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton15.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton15.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton15.ForeColor = System.Drawing.Color.White;
            this.gunaButton15.Image = null;
            this.gunaButton15.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton15.Location = new System.Drawing.Point(189, 460);
            this.gunaButton15.Name = "gunaButton15";
            this.gunaButton15.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton15.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton15.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton15.OnHoverImage = null;
            this.gunaButton15.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton15.Radius = 10;
            this.gunaButton15.Size = new System.Drawing.Size(163, 39);
            this.gunaButton15.TabIndex = 26;
            this.gunaButton15.Text = "Visit";
            this.gunaButton15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gunaCirclePictureBox3
            // 
            this.gunaCirclePictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox3.Location = new System.Drawing.Point(97, 120);
            this.gunaCirclePictureBox3.Name = "gunaCirclePictureBox3";
            this.gunaCirclePictureBox3.Size = new System.Drawing.Size(346, 310);
            this.gunaCirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox3.TabIndex = 3;
            this.gunaCirclePictureBox3.TabStop = false;
            this.gunaCirclePictureBox3.UseTransfarantBackground = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(165, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 21);
            this.label7.TabIndex = 2;
            this.label7.Text = "අපගේ ප්‍රියතම නිෂ්පාදන";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(129, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(283, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Our Best Seller Products";
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton1.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton1.ForeColor = System.Drawing.Color.White;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(65, 360);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Radius = 10;
            this.gunaButton1.Size = new System.Drawing.Size(163, 39);
            this.gunaButton1.TabIndex = 21;
            this.gunaButton1.Text = "Raw Material ";
            this.gunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 63);
            this.label2.TabIndex = 20;
            this.label2.Text = "ඔබට අවශ්‍ය සියලු ආයුර්වේද \r\nඅමුද්‍රවය මිලදී ගැනීම සදහා\r\nපිවිසෙන්න.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 248);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 23);
            this.label1.TabIndex = 19;
            this.label1.Text = "Raw Material ";
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(46, 30);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(200, 200);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 18;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(183)))), ((int)(((byte)(72)))));
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(331, 360);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Radius = 10;
            this.gunaButton2.Size = new System.Drawing.Size(163, 39);
            this.gunaButton2.TabIndex = 25;
            this.gunaButton2.Text = "PRODUCTS";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(304, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 63);
            this.label3.TabIndex = 24;
            this.label3.Text = "ඔබට අවශ්‍ය සියලු ආයුර්වේද \r\nනිශ්පාදන මිලදී ගැනීම සදහා\r\nපිවිසෙන්න.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(323, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 23);
            this.label4.TabIndex = 23;
            this.label4.Text = "Ayurvedic Products";
            // 
            // gunaCirclePictureBox2
            // 
            this.gunaCirclePictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox2.Image")));
            this.gunaCirclePictureBox2.Location = new System.Drawing.Point(312, 30);
            this.gunaCirclePictureBox2.Name = "gunaCirclePictureBox2";
            this.gunaCirclePictureBox2.Size = new System.Drawing.Size(200, 200);
            this.gunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox2.TabIndex = 22;
            this.gunaCirclePictureBox2.TabStop = false;
            this.gunaCirclePictureBox2.UseTransfarantBackground = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.gunaButton8);
            this.panel1.Controls.Add(this.gunaButton7);
            this.panel1.Controls.Add(this.gunaButton6);
            this.panel1.Controls.Add(this.gunaButton5);
            this.panel1.Controls.Add(this.gunaButton4);
            this.panel1.Controls.Add(this.gunaButton3);
            this.panel1.Location = new System.Drawing.Point(331, 400);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(163, 182);
            this.panel1.TabIndex = 26;
            // 
            // gunaButton8
            // 
            this.gunaButton8.AnimationHoverSpeed = 0.07F;
            this.gunaButton8.AnimationSpeed = 0.03F;
            this.gunaButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton8.BorderColor = System.Drawing.Color.White;
            this.gunaButton8.BorderSize = 1;
            this.gunaButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton8.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton8.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton8.ForeColor = System.Drawing.Color.Black;
            this.gunaButton8.Image = null;
            this.gunaButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton8.Location = new System.Drawing.Point(0, 150);
            this.gunaButton8.Name = "gunaButton8";
            this.gunaButton8.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton8.OnHoverImage = null;
            this.gunaButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton8.Radius = 10;
            this.gunaButton8.Size = new System.Drawing.Size(163, 30);
            this.gunaButton8.TabIndex = 27;
            this.gunaButton8.Text = "Guli Or Pill";
            this.gunaButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton8.Click += new System.EventHandler(this.gunaButton8_Click);
            // 
            // gunaButton7
            // 
            this.gunaButton7.AnimationHoverSpeed = 0.07F;
            this.gunaButton7.AnimationSpeed = 0.03F;
            this.gunaButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton7.BorderColor = System.Drawing.Color.White;
            this.gunaButton7.BorderSize = 1;
            this.gunaButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton7.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton7.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton7.ForeColor = System.Drawing.Color.Black;
            this.gunaButton7.Image = null;
            this.gunaButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton7.Location = new System.Drawing.Point(0, 120);
            this.gunaButton7.Name = "gunaButton7";
            this.gunaButton7.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton7.OnHoverImage = null;
            this.gunaButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton7.Radius = 10;
            this.gunaButton7.Size = new System.Drawing.Size(163, 30);
            this.gunaButton7.TabIndex = 26;
            this.gunaButton7.Text = "Tablets";
            this.gunaButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton7.Click += new System.EventHandler(this.gunaButton7_Click);
            // 
            // gunaButton6
            // 
            this.gunaButton6.AnimationHoverSpeed = 0.07F;
            this.gunaButton6.AnimationSpeed = 0.03F;
            this.gunaButton6.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton6.BorderColor = System.Drawing.Color.White;
            this.gunaButton6.BorderSize = 1;
            this.gunaButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton6.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton6.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton6.ForeColor = System.Drawing.Color.Black;
            this.gunaButton6.Image = null;
            this.gunaButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton6.Location = new System.Drawing.Point(0, 90);
            this.gunaButton6.Name = "gunaButton6";
            this.gunaButton6.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton6.OnHoverImage = null;
            this.gunaButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton6.Radius = 10;
            this.gunaButton6.Size = new System.Drawing.Size(163, 30);
            this.gunaButton6.TabIndex = 25;
            this.gunaButton6.Text = "Powder";
            this.gunaButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton6.Click += new System.EventHandler(this.gunaButton6_Click);
            // 
            // gunaButton5
            // 
            this.gunaButton5.AnimationHoverSpeed = 0.07F;
            this.gunaButton5.AnimationSpeed = 0.03F;
            this.gunaButton5.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton5.BorderColor = System.Drawing.Color.White;
            this.gunaButton5.BorderSize = 1;
            this.gunaButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton5.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton5.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton5.ForeColor = System.Drawing.Color.Black;
            this.gunaButton5.Image = null;
            this.gunaButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton5.Location = new System.Drawing.Point(0, 60);
            this.gunaButton5.Name = "gunaButton5";
            this.gunaButton5.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton5.OnHoverImage = null;
            this.gunaButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton5.Radius = 10;
            this.gunaButton5.Size = new System.Drawing.Size(163, 30);
            this.gunaButton5.TabIndex = 24;
            this.gunaButton5.Text = "Tonic & Oil";
            this.gunaButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton5.Click += new System.EventHandler(this.gunaButton5_Click);
            // 
            // gunaButton4
            // 
            this.gunaButton4.AnimationHoverSpeed = 0.07F;
            this.gunaButton4.AnimationSpeed = 0.03F;
            this.gunaButton4.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton4.BorderColor = System.Drawing.Color.White;
            this.gunaButton4.BorderSize = 1;
            this.gunaButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton4.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton4.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton4.ForeColor = System.Drawing.Color.Black;
            this.gunaButton4.Image = null;
            this.gunaButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton4.Location = new System.Drawing.Point(0, 30);
            this.gunaButton4.Name = "gunaButton4";
            this.gunaButton4.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton4.OnHoverImage = null;
            this.gunaButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton4.Radius = 10;
            this.gunaButton4.Size = new System.Drawing.Size(163, 30);
            this.gunaButton4.TabIndex = 23;
            this.gunaButton4.Text = "Cream & Gel";
            this.gunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton4.Click += new System.EventHandler(this.gunaButton4_Click);
            // 
            // gunaButton3
            // 
            this.gunaButton3.AnimationHoverSpeed = 0.07F;
            this.gunaButton3.AnimationSpeed = 0.03F;
            this.gunaButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton3.BorderColor = System.Drawing.Color.White;
            this.gunaButton3.BorderSize = 1;
            this.gunaButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton3.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton3.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton3.ForeColor = System.Drawing.Color.Black;
            this.gunaButton3.Image = null;
            this.gunaButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton3.Location = new System.Drawing.Point(0, 0);
            this.gunaButton3.Name = "gunaButton3";
            this.gunaButton3.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton3.OnHoverImage = null;
            this.gunaButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton3.Radius = 10;
            this.gunaButton3.Size = new System.Drawing.Size(163, 30);
            this.gunaButton3.TabIndex = 22;
            this.gunaButton3.Text = "Balm";
            this.gunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton3.Click += new System.EventHandler(this.gunaButton3_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.gunaButton9);
            this.panel2.Controls.Add(this.gunaButton10);
            this.panel2.Controls.Add(this.gunaButton11);
            this.panel2.Controls.Add(this.gunaButton12);
            this.panel2.Controls.Add(this.gunaButton13);
            this.panel2.Controls.Add(this.gunaButton14);
            this.panel2.Location = new System.Drawing.Point(65, 400);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(163, 182);
            this.panel2.TabIndex = 27;
            // 
            // gunaButton9
            // 
            this.gunaButton9.AnimationHoverSpeed = 0.07F;
            this.gunaButton9.AnimationSpeed = 0.03F;
            this.gunaButton9.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton9.BorderColor = System.Drawing.Color.White;
            this.gunaButton9.BorderSize = 1;
            this.gunaButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton9.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton9.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton9.ForeColor = System.Drawing.Color.Black;
            this.gunaButton9.Image = null;
            this.gunaButton9.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton9.Location = new System.Drawing.Point(0, 150);
            this.gunaButton9.Name = "gunaButton9";
            this.gunaButton9.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton9.OnHoverImage = null;
            this.gunaButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton9.Radius = 10;
            this.gunaButton9.Size = new System.Drawing.Size(163, 30);
            this.gunaButton9.TabIndex = 27;
            this.gunaButton9.Text = "Oils";
            this.gunaButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton9.Click += new System.EventHandler(this.gunaButton9_Click);
            // 
            // gunaButton10
            // 
            this.gunaButton10.AnimationHoverSpeed = 0.07F;
            this.gunaButton10.AnimationSpeed = 0.03F;
            this.gunaButton10.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton10.BorderColor = System.Drawing.Color.White;
            this.gunaButton10.BorderSize = 1;
            this.gunaButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton10.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton10.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton10.ForeColor = System.Drawing.Color.Black;
            this.gunaButton10.Image = null;
            this.gunaButton10.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton10.Location = new System.Drawing.Point(0, 120);
            this.gunaButton10.Name = "gunaButton10";
            this.gunaButton10.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton10.OnHoverImage = null;
            this.gunaButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton10.Radius = 10;
            this.gunaButton10.Size = new System.Drawing.Size(163, 30);
            this.gunaButton10.TabIndex = 26;
            this.gunaButton10.Text = "Seeds & Fruits";
            this.gunaButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton10.Click += new System.EventHandler(this.gunaButton10_Click);
            // 
            // gunaButton11
            // 
            this.gunaButton11.AnimationHoverSpeed = 0.07F;
            this.gunaButton11.AnimationSpeed = 0.03F;
            this.gunaButton11.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton11.BorderColor = System.Drawing.Color.White;
            this.gunaButton11.BorderSize = 1;
            this.gunaButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton11.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton11.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton11.ForeColor = System.Drawing.Color.Black;
            this.gunaButton11.Image = null;
            this.gunaButton11.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton11.Location = new System.Drawing.Point(0, 90);
            this.gunaButton11.Name = "gunaButton11";
            this.gunaButton11.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton11.OnHoverImage = null;
            this.gunaButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton11.Radius = 10;
            this.gunaButton11.Size = new System.Drawing.Size(163, 30);
            this.gunaButton11.TabIndex = 25;
            this.gunaButton11.Text = " Flowers";
            this.gunaButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton11.Click += new System.EventHandler(this.gunaButton11_Click);
            // 
            // gunaButton12
            // 
            this.gunaButton12.AnimationHoverSpeed = 0.07F;
            this.gunaButton12.AnimationSpeed = 0.03F;
            this.gunaButton12.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton12.BorderColor = System.Drawing.Color.White;
            this.gunaButton12.BorderSize = 1;
            this.gunaButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton12.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton12.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton12.ForeColor = System.Drawing.Color.Black;
            this.gunaButton12.Image = null;
            this.gunaButton12.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton12.Location = new System.Drawing.Point(0, 60);
            this.gunaButton12.Name = "gunaButton12";
            this.gunaButton12.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton12.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton12.OnHoverImage = null;
            this.gunaButton12.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton12.Radius = 10;
            this.gunaButton12.Size = new System.Drawing.Size(163, 30);
            this.gunaButton12.TabIndex = 24;
            this.gunaButton12.Text = "Barks & Heartwood";
            this.gunaButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton12.Click += new System.EventHandler(this.gunaButton12_Click);
            // 
            // gunaButton13
            // 
            this.gunaButton13.AnimationHoverSpeed = 0.07F;
            this.gunaButton13.AnimationSpeed = 0.03F;
            this.gunaButton13.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton13.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton13.BorderColor = System.Drawing.Color.White;
            this.gunaButton13.BorderSize = 1;
            this.gunaButton13.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton13.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton13.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton13.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton13.ForeColor = System.Drawing.Color.Black;
            this.gunaButton13.Image = null;
            this.gunaButton13.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton13.Location = new System.Drawing.Point(0, 30);
            this.gunaButton13.Name = "gunaButton13";
            this.gunaButton13.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton13.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton13.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton13.OnHoverImage = null;
            this.gunaButton13.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton13.Radius = 10;
            this.gunaButton13.Size = new System.Drawing.Size(163, 30);
            this.gunaButton13.TabIndex = 23;
            this.gunaButton13.Text = "Leaves";
            this.gunaButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton13.Click += new System.EventHandler(this.gunaButton13_Click);
            // 
            // gunaButton14
            // 
            this.gunaButton14.AnimationHoverSpeed = 0.07F;
            this.gunaButton14.AnimationSpeed = 0.03F;
            this.gunaButton14.BackColor = System.Drawing.Color.Transparent;
            this.gunaButton14.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton14.BorderColor = System.Drawing.Color.White;
            this.gunaButton14.BorderSize = 1;
            this.gunaButton14.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton14.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaButton14.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton14.Font = new System.Drawing.Font("Century Gothic", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButton14.ForeColor = System.Drawing.Color.Black;
            this.gunaButton14.Image = null;
            this.gunaButton14.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton14.Location = new System.Drawing.Point(0, 0);
            this.gunaButton14.Name = "gunaButton14";
            this.gunaButton14.OnHoverBaseColor = System.Drawing.Color.White;
            this.gunaButton14.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton14.OnHoverForeColor = System.Drawing.Color.Black;
            this.gunaButton14.OnHoverImage = null;
            this.gunaButton14.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton14.Radius = 10;
            this.gunaButton14.Size = new System.Drawing.Size(163, 30);
            this.gunaButton14.TabIndex = 22;
            this.gunaButton14.Text = " Herbs";
            this.gunaButton14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton14.Click += new System.EventHandler(this.gunaButton14_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.gunaCirclePictureBox4);
            this.panel3.Location = new System.Drawing.Point(46, 430);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(457, 228);
            this.panel3.TabIndex = 24;
            // 
            // gunaCirclePictureBox4
            // 
            this.gunaCirclePictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaCirclePictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox4.Image")));
            this.gunaCirclePictureBox4.Location = new System.Drawing.Point(3, 3);
            this.gunaCirclePictureBox4.Name = "gunaCirclePictureBox4";
            this.gunaCirclePictureBox4.Size = new System.Drawing.Size(451, 280);
            this.gunaCirclePictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox4.TabIndex = 23;
            this.gunaCirclePictureBox4.TabStop = false;
            this.gunaCirclePictureBox4.UseTransfarantBackground = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "photo_2021-01-30_17-53-16.jpg");
            this.imageList1.Images.SetKeyName(1, "photo_2021-01-30_17-53-19.jpg");
            this.imageList1.Images.SetKeyName(2, "photo_2021-01-30_18-00-22.jpg");
            this.imageList1.Images.SetKeyName(3, "photo_2021-01-30_18-00-23.jpg");
            this.imageList1.Images.SetKeyName(4, "photo_2021-01-30_18-00-24 (2).jpg");
            this.imageList1.Images.SetKeyName(5, "photo_2021-01-30_18-00-24.jpg");
            this.imageList1.Images.SetKeyName(6, "photo_2021-01-30_18-00-25 (2).jpg");
            this.imageList1.Images.SetKeyName(7, "photo_2021-01-30_18-00-25.jpg");
            this.imageList1.Images.SetKeyName(8, "photo_2021-01-30_18-28-08.jpg");
            this.imageList1.Images.SetKeyName(9, "photo_2021-01-30_18-00-24.jpg");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // BuyHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1185, 609);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.gunaButton2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gunaCirclePictureBox2);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gunaCirclePictureBox1);
            this.Controls.Add(this.gunaElipsePanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BuyHomePage";
            this.Text = "BuyHomePage";
            this.Load += new System.EventHandler(this.BuyHomePage_Load);
            this.gunaElipsePanel1.ResumeLayout(false);
            this.gunaElipsePanel2.ResumeLayout(false);
            this.gunaElipsePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaElipsePanel gunaElipsePanel1;
        private Guna.UI.WinForms.GunaElipsePanel gunaElipsePanel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private Guna.UI.WinForms.GunaButton gunaButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox2;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton gunaButton8;
        private Guna.UI.WinForms.GunaButton gunaButton7;
        private Guna.UI.WinForms.GunaButton gunaButton6;
        private Guna.UI.WinForms.GunaButton gunaButton5;
        private Guna.UI.WinForms.GunaButton gunaButton4;
        private Guna.UI.WinForms.GunaButton gunaButton3;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI.WinForms.GunaButton gunaButton9;
        private Guna.UI.WinForms.GunaButton gunaButton10;
        private Guna.UI.WinForms.GunaButton gunaButton11;
        private Guna.UI.WinForms.GunaButton gunaButton12;
        private Guna.UI.WinForms.GunaButton gunaButton13;
        private Guna.UI.WinForms.GunaButton gunaButton14;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox4;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox3;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
        private Guna.UI.WinForms.GunaButton gunaButton15;
    }
}